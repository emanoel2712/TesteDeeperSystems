/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;



import conexao.ConnectionFactory;
import java.sql.Blob;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import java.sql.SQLException;
import java.util.ArrayList;
import javax.xml.bind.DatatypeConverter;

import model.Foto;
import org.apache.tomcat.util.codec.binary.Base64;

/**
 *
 * @author emano
 */
public class FotoDao extends ConnectionFactory {

    private static FotoDao instance;

    /**
     * Metodo responsovel por criar uma instancia da classe ClienteDAO.
     */
    
    
    public static FotoDao getInstance() {
        if (instance == null) {
            instance = new FotoDao();
        }
        return instance;
    }

    /**
     * @return ArrayList<Cliente>
     * Metodo responsavel por buscar e listar todos os clientes gravados no
     * banco de dados.
     */
    public ArrayList<Foto> listarTodos() {
        Connection conexao = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        ArrayList<Foto> fotos = null;

        conexao = criarConexao();
        fotos = new ArrayList<>();
//      fotos = new ArrayList<Foto>();
        try {
            pstmt = conexao
                    .prepareStatement("SELECT * FROM foto ORDER BY id");
            rs = pstmt.executeQuery();
            
            while (rs.next()) {
                Foto foto = new Foto();
                foto.setId(rs.getInt("id"));
                
                
//                 byte[] imageBytes = rs.getBytes("imagem");
//                String imageBase64 = DatatypeConverter.printBase64Binary(imageBytes);                           
//                foto.setImagem(rs.getBlob(imageBase64));
                foto.setNomeArquivo(rs.getString("nomeArquivo"));
//                foto.setImagem(new String(Base64.encodeBase64(rs.getBlob("imagem"))));
//               
                fotos.add(foto);
            }

        } catch (Exception e) {
            System.out.println("Erro ao listar todas as fotos: " + e);
            e.printStackTrace();
        } finally {
            fecharConexao(conexao, pstmt, rs);
        }
        return fotos;
    }

    /**
     * Busca um cliente no banco dado um id.
     *
     * @param id
     * @return cliente
     */
    public Foto getById(long id) {

        Connection conexao = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        Foto foto = null;
        conexao = criarConexao();

        try {
            pstmt = conexao
                    .prepareStatement("SELECT * FROM foto WHERE id = ?");
            pstmt.setLong(1, id);
            rs = pstmt.executeQuery();
            while (rs.next()) {
                foto = new Foto();
                foto.setId(rs.getInt("id"));
//                foto.setNome(rs.getString("nome"));
//				foto.setCpf(rs.getString("cpf"));
//				foto.setEndereco(rs.getString("endereco"));
            }
        } catch (Exception e) {
            System.out
                    .println("Erro ao buscar foto com ID=" + id + "\n" + e);
            e.printStackTrace();
        } finally {
            fecharConexao(conexao, pstmt, rs);
        }

        return foto;

    }

    /**
     * Metodo responsavel por gravar cliente no banco de dados.
     *
     * @param cliente
     * @return verdade se cliente gravado e falso se nao gravado
     */
    public boolean insert(Foto foto) {
//        String nome = foto.getNome();
//		String cpf = cliente.getCpf();
//		String endereco = cliente.getEndereco();;
        boolean isGravado = false;
        PreparedStatement pstmt = null;
        Connection conexao = criarConexao();
        try {
            pstmt = conexao
                    .prepareStatement("insert into foto(nome)"
                            + "values(?)");
//            pstmt.setString(1, nome);
//			pstmt.setString(2, cpf);
//			pstmt.setString(3, endereco);
            boolean execute = pstmt.execute();
            isGravado = true;
            System.out.println("Respota do insert: " + execute);

        } catch (SQLException e) {
            // TODO Auto-generated catch block
            isGravado = false;
            e.printStackTrace();

        }
        return isGravado;
    }

    /**
     * Metodo responsavel por atualizar cliente na base de dados
     *
     * @param cliente
     * @return verdade se atualizado e falso se nao.
     */

//	}
        /**
         * Metodo responsavel por deletar cliente na base de dados.
         *
         * @param id
         * @return Verdade se cliente deletado e falso se nao.
         */
//	public boolean delete(Cliente cliente) {
//		boolean isDeletado = false;
//		PreparedStatement pstmt = null;
//		Connection conexao = criarConexao();
//		try {
//			pstmt = conexao.prepareStatement("DELETE FROM cliente WHERE id = ?");
//			pstmt.setInt(1, cliente.getId());
//			boolean execute = pstmt.execute();
//			isDeletado = true;
//			System.out.println("Respota do delete: " + execute);
//
//		} catch (SQLException e) {
//			isDeletado = false;
//			e.printStackTrace();
//
//		} finally {
//			fecharConexao(conexao, pstmt, null);
//		}
//		return isDeletado;
//	}
    
}
