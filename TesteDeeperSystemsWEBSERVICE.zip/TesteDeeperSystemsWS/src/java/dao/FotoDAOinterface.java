/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.util.List;
import model.Foto;

/**
 *
 * @author emano
 */
public interface FotoDAOinterface {
    	public Foto save(Foto foto);

	public List<Foto> findByName(Foto foto);

	public List<Foto> findAll();
}

