/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ws;

import control.FotoController;
import java.util.ArrayList;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.UriInfo;
import javax.ws.rs.Consumes;
import javax.ws.rs.Produces;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PUT;
import javax.ws.rs.core.MediaType;
import model.Foto;

/**
 * REST Web Service
 *
 * @author emano
 */
@Path("testedeepersystems")
public class TesteDeeperSystemsWS {

     @GET
    @Produces("application/json")
    @Path("foto")
    public ArrayList<Foto> listarFotos() {
        System.out.println("Fotos encontradas no banco");
        return new FotoController().listarTodos();
    }
    
    
    /**
     * Retrieves representation of an instance of com.myapp.struts.TesteDeeperSystemsWSResource
     * @return an instance of java.lang.String
     */
  
}
